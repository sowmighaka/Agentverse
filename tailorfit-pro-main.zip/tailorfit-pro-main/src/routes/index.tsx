import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";

// ⚠️ Swap this once your backend is deployed.
const BACKEND_URL = "https://your-backend.example.com";

export const Route = createFileRoute("/")({
  component: TailorFit,
});

type JobInputType = "text" | "url";

type ConfidenceTag = {
  label: string;
  level: "match" | "review";
};

type TailoredLine = {
  text: string;
  changed?: boolean;
  tags?: ConfidenceTag[];
};

type TailorResponse = {
  verification_status: "verified" | "needs_review";
  verification_message?: string;
  original_resume: string;
  tailored_resume: string | TailoredLine[];
  diff_explanation: string[];
  cover_letter: string;
  tech_stack?: string[];
};

const STATUS_STEPS = [
  "Reading job posting...",
  "Analyzing engineering blog...",
  "Checking GitHub tech stack...",
  "Matching your experience...",
  "Rewriting your resume...",
  "Fact-checking the result...",
];

function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("tf-in");
            io.unobserve(e.target);
          }
        }
      },
      { threshold: 0.15 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return ref;
}

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={`tf-reveal ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

function StatusRotator() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % STATUS_STEPS.length), 2000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex items-center gap-3">
      <span className="flex items-center gap-1.5">
        <span className="tf-dot" />
        <span className="tf-dot" />
        <span className="tf-dot" />
      </span>
      <span key={i} className="tf-fade text-sm text-[#a1a1aa] font-mono">
        {STATUS_STEPS[i]}
      </span>
    </div>
  );
}

function ConfidencePill({ tag }: { tag: ConfidenceTag }) {
  const color =
    tag.level === "match"
      ? "text-[#34d399] border-[#34d399]/40 bg-[#34d399]/10"
      : "text-[#fbbf24] border-[#fbbf24]/40 bg-[#fbbf24]/10";
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-mono ${color}`}
    >
      {tag.label}
    </span>
  );
}

function normalizeTailored(v: TailorResponse["tailored_resume"]): TailoredLine[] {
  if (Array.isArray(v)) return v;
  return v.split("\n").map((text) => ({ text }));
}

function TailorFit() {
  const [resume, setResume] = useState("");
  const [jobInputType, setJobInputType] = useState<JobInputType>("text");
  const [jobInput, setJobInput] = useState("");
  const [blogUrls, setBlogUrls] = useState("");
  const [githubOrg, setGithubOrg] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TailorResponse | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const resultsRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (result && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [result]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);
    setLoading(true);
    try {
      const res = await fetch(`${BACKEND_URL}/api/tailor`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resume_text: resume,
          job_input: jobInput,
          job_input_type: jobInputType,
          blog_urls: blogUrls
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
          github_org: githubOrg.trim() || null,
        }),
      });
      if (!res.ok) throw new Error(`Request failed (${res.status})`);
      const data = (await res.json()) as TailorResponse;
      setResult(data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong reaching the tailoring service.",
      );
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setResult(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function copy(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      /* ignore */
    }
  }

  const tailoredLines = result ? normalizeTailored(result.tailored_resume) : [];
  const tailoredText = tailoredLines.map((l) => l.text).join("\n");

  // Cursor spotlight
  const spotRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = spotRef.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      el.style.left = `${e.clientX}px`;
      el.style.top = `${e.clientY}px`;
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  // Tilt handler
  function tilt(e: React.MouseEvent<HTMLElement>) {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5;
    const y = (e.clientY - r.top) / r.height - 0.5;
    el.style.setProperty("--ry", `${x * 6}deg`);
    el.style.setProperty("--rx", `${-y * 6}deg`);
  }
  function resetTilt(e: React.MouseEvent<HTMLElement>) {
    e.currentTarget.style.setProperty("--ry", `0deg`);
    e.currentTarget.style.setProperty("--rx", `0deg`);
  }

  // Magnetic handler — element leans toward the cursor
  function magnet(e: React.MouseEvent<HTMLElement>) {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    const y = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    el.style.transform = `translate(${x * 6}px, ${y * 6}px)`;
  }
  function resetMagnet(e: React.MouseEvent<HTMLElement>) {
    e.currentTarget.style.transform = "";
  }

  // Particle field — generated after mount (client-only) to avoid SSR hydration mismatch
  const [particles, setParticles] = useState<
    {
      id: number;
      left: number;
      size: number;
      dur: number;
      delay: number;
      drift: string;
      hue: string;
    }[]
  >([]);
  useEffect(() => {
    setParticles(
      Array.from({ length: 26 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 2 + Math.random() * 3,
        dur: 9 + Math.random() * 12,
        delay: Math.random() * 12,
        drift: `${(Math.random() - 0.5) * 120}px`,
        hue: ["#8b5cf6", "#d946ef", "#22d3ee"][i % 3],
      })),
    );
  }, []);

  return (
    <div className="relative min-h-screen">
      {/* Background */}
      <div className="tf-bg" aria-hidden>
        <div className="tf-aurora" />
        <div className="tf-glow-violet" />
        <div className="tf-glow-cyan" />
        <div className="tf-orb tf-orb-a" />
        <div className="tf-orb tf-orb-b" />
        <div className="tf-orb tf-orb-c" />
        <div className="tf-dots" />
        <div className="tf-scanline" />
        <div className="tf-particles" aria-hidden>
          {particles.map((p) => (
            <span
              key={p.id}
              className="tf-particle"
              style={{
                left: `${p.left}%`,
                width: `${p.size}px`,
                height: `${p.size}px`,
                animationDuration: `${p.dur}s`,
                animationDelay: `${p.delay}s`,
                background: p.hue,
                boxShadow: `0 0 6px ${p.hue}`,
                ["--drift" as string]: p.drift,
              }}
            />
          ))}
        </div>
      </div>
      <div ref={spotRef} className="tf-spotlight" aria-hidden />

      <main className="relative mx-auto max-w-6xl px-6 pb-32 pt-24 sm:pt-32">
        {/* HERO */}
        <section className="mx-auto max-w-3xl text-center">
          <div className="tf-rise" style={{ animationDelay: "0ms" }}>
            <span className="glass-chip tf-chip-glow inline-flex items-center px-3 py-1 text-xs">
              <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-[#34d399] shadow-[0_0_8px_#34d399]" />
              <span className="text-gradient font-medium">
                AI-powered application tailoring
              </span>
            </span>
          </div>
          <h1
            className="tf-rise mt-6 text-4xl font-bold tracking-tight text-[#f5f5f7] sm:text-6xl"
            style={{ animationDelay: "150ms" }}
          >
            Tailored to what they{" "}
            <span className="tf-shimmer tf-glitch" data-text="actually build">
              actually build
            </span>
          </h1>
          <p
            className="tf-rise mx-auto mt-5 max-w-xl text-base text-[#a1a1aa] sm:text-lg"
            style={{ animationDelay: "300ms" }}
          >
            Not keyword guessing — grounded in their real job posting,
            engineering blog, and codebase.
          </p>

          <div
            className="tf-rise mt-8 flex flex-wrap items-center justify-center gap-2"
            style={{ animationDelay: "450ms" }}
          >
            {[
              { icon: "📄", label: "Job posting" },
              { icon: "✍️", label: "Engineering blog" },
              { icon: "⌘", label: "GitHub activity" },
            ].map((c) => (
              <span
                key={c.label}
                className="glass-chip tf-magnetic inline-flex items-center gap-2 px-3 py-1.5 text-xs text-[#f5f5f7]"
                onMouseMove={magnet}
                onMouseLeave={resetMagnet}
              >
                <span aria-hidden>{c.icon}</span>
                <span className="font-mono">{c.label}</span>
              </span>
            ))}
          </div>

          {/* Signals marquee */}
          <div
            className="tf-rise tf-marquee mt-10 border-y border-white/5 py-3"
            style={{ animationDelay: "600ms" }}
          >
            <div className="tf-marquee-track font-mono text-[11px] text-[#71717a]">
              {[...Array(2)].map((_, dup) => (
                <div key={dup} className="inline-flex items-center gap-8">
                  {[
                    "TypeScript · 87%",
                    "Rust · 42%",
                    "commits/week: 214",
                    "postgres · verified",
                    "kafka · verified",
                    "eng blog: 34 posts",
                    "open PRs: 61",
                    "React 19 · adjacent-match",
                    "GraphQL · direct-match",
                  ].map((s) => (
                    <span key={`${dup}-${s}`} className="inline-flex items-center gap-2">
                      <span className="h-1 w-1 rounded-full bg-[#8b5cf6]" />
                      {s}
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Wave divider */}
        <div className="tf-wave my-12 opacity-30" aria-hidden>
          <svg viewBox="0 0 1200 40" preserveAspectRatio="none" fill="none">
            <path
              d="M0 20 Q 150 0 300 20 T 600 20 T 900 20 T 1200 20 V40 H0 Z"
              fill="url(#wave-grad)"
            />
            <path
              d="M1200 20 Q 1350 0 1500 20 T 1800 20 T 2100 20 T 2400 20 V40 H1200 Z"
              fill="url(#wave-grad)"
            />
            <defs>
              <linearGradient id="wave-grad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#d946ef" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.5" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* FORM */}
        <Reveal className="mx-auto mt-4 max-w-[700px]">
          <form
            onSubmit={onSubmit}
            className={`glass-panel tf-breathe tf-tilt p-6 sm:p-8 transition-opacity ${loading ? "opacity-60 pointer-events-none" : ""}`}
            onMouseMove={tilt}
            onMouseLeave={resetTilt}
          >
            <Reveal delay={0}>
              <label className="block">
                <span className="mb-2 block text-sm font-medium text-[#f5f5f7]">
                  Your resume
                </span>
                <textarea
                  className="tf-input min-h-[180px] resize-y"
                  placeholder="Paste your resume text here"
                  value={resume}
                  onChange={(e) => setResume(e.target.value)}
                  required
                />
              </label>
            </Reveal>

            <Reveal delay={80} className="mt-6">
              <span className="mb-2 block text-sm font-medium text-[#f5f5f7]">
                Target company
              </span>

              {/* Toggle */}
              <div className="glass-chip relative mb-3 inline-flex p-1 text-xs">
                {(["text", "url"] as const).map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setJobInputType(v)}
                    className={`relative z-10 rounded-full px-4 py-1.5 font-medium transition-colors ${
                      jobInputType === v ? "text-white" : "text-[#a1a1aa]"
                    }`}
                  >
                    {jobInputType === v && (
                      <span
                        className="absolute inset-0 -z-10 rounded-full"
                        style={{
                          background:
                            "linear-gradient(135deg,#8b5cf6,#d946ef)",
                        }}
                      />
                    )}
                    {v === "text" ? "Paste job description" : "Job posting URL"}
                  </button>
                ))}
              </div>

              {jobInputType === "text" ? (
                <textarea
                  className="tf-input min-h-[120px] resize-y"
                  placeholder="Paste the full job description"
                  value={jobInput}
                  onChange={(e) => setJobInput(e.target.value)}
                  required
                />
              ) : (
                <input
                  className="tf-input"
                  type="url"
                  placeholder="https://company.com/careers/senior-engineer"
                  value={jobInput}
                  onChange={(e) => setJobInput(e.target.value)}
                  required
                />
              )}
            </Reveal>

            <Reveal delay={160} className="mt-5">
              <label className="block">
                <span className="mb-2 block text-sm font-medium text-[#f5f5f7]">
                  Engineering blog URL(s){" "}
                  <span className="text-[#71717a]">— optional, comma separated</span>
                </span>
                <input
                  className="tf-input"
                  placeholder="https://company.com/blog, https://eng.company.com"
                  value={blogUrls}
                  onChange={(e) => setBlogUrls(e.target.value)}
                />
              </label>
            </Reveal>

            <Reveal delay={220} className="mt-5">
              <label className="block">
                <span className="mb-2 block text-sm font-medium text-[#f5f5f7]">
                  GitHub org name <span className="text-[#71717a]">— optional</span>
                </span>
                <input
                  className="tf-input"
                  placeholder="e.g. vercel"
                  value={githubOrg}
                  onChange={(e) => setGithubOrg(e.target.value)}
                />
              </label>
            </Reveal>

            <Reveal delay={280} className="mt-8">
              <button
                type="submit"
                className="btn-gradient tf-sheen w-full px-6 py-3.5 text-base"
                disabled={loading}
              >
                {loading ? "Working..." : "Generate Tailored Application"}
              </button>
            </Reveal>

            {loading && (
              <div className="mt-6 flex justify-center">
                <StatusRotator />
              </div>
            )}
          </form>

          {error && (
            <div
              className="glass-panel mt-6 border-l-4 p-5"
              style={{ borderLeftColor: "#ef4444" }}
            >
              <p className="text-sm font-medium text-[#f5f5f7]">
                We couldn't reach the tailoring service.
              </p>
              <p className="mt-1 text-sm text-[#a1a1aa]">{error}</p>
              <button
                type="button"
                onClick={(e) => onSubmit(e as unknown as FormEvent)}
                className="btn-outline-gradient mt-4 px-4 py-2 text-sm"
              >
                Retry
              </button>
            </div>
          )}
        </Reveal>

        {/* RESULTS */}
        {result && (
          <section ref={resultsRef} className="mt-28 scroll-mt-16">
            <h2
              className="tf-underline mb-6 text-center text-2xl font-bold tracking-tight text-[#f5f5f7]"
              style={{ ["--ud" as string]: "0.2s" }}
            >
              Your <span className="text-gradient">tailored</span> application
            </h2>
            <Reveal>
              <div
                className="glass-panel border-l-4 p-5"
                style={{
                  borderLeftColor:
                    result.verification_status === "verified"
                      ? "#34d399"
                      : "#fbbf24",
                }}
              >
                <p className="text-sm font-medium text-[#f5f5f7]">
                  {result.verification_status === "verified"
                    ? "Fact-checked — no unsupported claims found"
                    : "Some changes need your review before sending"}
                </p>
                {result.verification_message && (
                  <p className="mt-1 text-sm text-[#a1a1aa] font-mono">
                    {result.verification_message}
                  </p>
                )}
              </div>
            </Reveal>

            {result.tech_stack && result.tech_stack.length > 0 && (
              <Reveal delay={80} className="mt-6">
                <div className="glass-panel p-5">
                  <p className="mb-3 text-xs uppercase tracking-wider text-[#a1a1aa]">
                    Detected tech stack
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {result.tech_stack.map((t) => (
                      <span
                        key={t}
                        className="glass-chip px-2.5 py-1 text-[11px] font-mono text-[#f5f5f7]"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </Reveal>
            )}

            <div className="mt-6 grid gap-6 md:grid-cols-2">
              <Reveal delay={120}>
                <div className="glass-panel h-full p-6">
                  <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-[#a1a1aa]">
                    Original
                  </h3>
                  <pre className="whitespace-pre-wrap break-words text-sm leading-relaxed text-[#a1a1aa]">
                    {result.original_resume}
                  </pre>
                </div>
              </Reveal>

              <Reveal delay={180}>
                <div className="glass-panel h-full p-6">
                  <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-[#f5f5f7]">
                    <span className="text-gradient">Tailored</span>
                  </h3>
                  <div className="space-y-1.5 text-sm leading-relaxed text-[#f5f5f7]">
                    {tailoredLines.map((line, idx) => (
                      <div
                        key={idx}
                        className={
                          line.changed
                            ? "border-l-2 border-[#8b5cf6] pl-3"
                            : "pl-3"
                        }
                      >
                        <span className="whitespace-pre-wrap">{line.text}</span>
                        {line.tags && line.tags.length > 0 && (
                          <span className="ml-2 inline-flex flex-wrap gap-1 align-middle">
                            {line.tags.map((t, i) => (
                              <ConfidencePill key={i} tag={t} />
                            ))}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>
            </div>

            <Reveal delay={240} className="mt-6">
              <div className="glass-panel p-6">
                <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-[#f5f5f7]">
                  Why these changes
                </h3>
                <ul className="space-y-2 text-sm text-[#a1a1aa]">
                  {result.diff_explanation.map((d, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-gradient">→</span>
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>

            <Reveal delay={300} className="mt-6">
              <div className="glass-panel p-6">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-[#f5f5f7]">
                    Cover Letter
                  </h3>
                  <button
                    type="button"
                    onClick={() => copy(result.cover_letter, "cover")}
                    className="btn-outline-gradient px-3 py-1.5 text-xs"
                  >
                    {copied === "cover" ? "Copied" : "Copy"}
                  </button>
                </div>
                <pre className="whitespace-pre-wrap break-words text-sm leading-relaxed text-[#f5f5f7]">
                  {result.cover_letter}
                </pre>
              </div>
            </Reveal>

            <Reveal delay={360} className="mt-8">
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => copy(tailoredText, "resume")}
                  className="btn-outline-gradient px-5 py-2.5 text-sm"
                >
                  {copied === "resume" ? "Copied" : "Copy resume"}
                </button>
                <button
                  type="button"
                  onClick={() => copy(result.cover_letter, "cover2")}
                  className="btn-outline-gradient px-5 py-2.5 text-sm"
                >
                  {copied === "cover2" ? "Copied" : "Copy cover letter"}
                </button>
                <button
                  type="button"
                  onClick={reset}
                  className="btn-outline-gradient px-5 py-2.5 text-sm"
                >
                  Start over
                </button>
              </div>
            </Reveal>
          </section>
        )}
      </main>
    </div>
  );
}
